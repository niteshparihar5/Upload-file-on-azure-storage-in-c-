﻿using System;
using System.IO;
using Microsoft.Azure;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;

namespace AzureDEMO
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            AzStorages azStorages = new AzStorages();
            azStorages.UploadFile();
            Console.ReadLine();
        }

    }

    public class AzStorages
    {
        public void UploadFile() 
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=niteshblobstorage;");
            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.GetContainerReference("blobcontainer");
            // Retrieve reference to a blob named "myblob".
            CloudBlockBlob blockBlob = container.GetBlockBlobReference("Rentreceipt1.pdf");
            // Create or overwrite the "myblob" blob with contents from a local file.
            using (var fileStream = System.IO.File.OpenRead(@"D:\RentReceipt.pdf"))
            {                
                blockBlob.UploadFromStream(fileStream);
                string filepath = blockBlob.Uri.ToString();
            }
        }

        public void DownLoadFile()
        {
            Console.WriteLine("File download start");
            string filename = "Rentreceipt.pdf";
            MemoryStream ms = new MemoryStream();
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=niteshblobstorage;");
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("blobcontainer");

            if (container.Exists())
                {
                    CloudBlob file = container.GetBlobReference(filename);

                    if (file.Exists())
                    {
                        file.DownloadToStream(ms);
                        Stream blobStream = file.OpenReadAsync().Result;
                   //blobStream.
                    //System.IO.File(blobStream, file.Properties.ContentType, file.Name);
                    }                   
                }
               
            }

        public void DeleteFile()
        {
            Console.WriteLine("File download start");
            string filename = "Rentreceipt.pdf";
            MemoryStream ms = new MemoryStream();
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=niteshblobstorage;");
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference("blobcontainer");

            if (container.Exists())
            {
                CloudBlob file = container.GetBlobReference(filename);

                if (file.Exists())
                { file.Delete();                   
                }
            }

        }

    }
}
